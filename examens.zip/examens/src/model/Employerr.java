/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author HP
 */
public class Employerr {
     
    String refernce;
    String nom;
    String tel_fix;
    String nmobile;
    String resp_hirar;
    String service;
    String sos_pal;

  

    

    public String getRefernce() {
        return refernce;
    }

    public void setRefernce(String refernce) {
        this.refernce = refernce;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getTel_fix() {
        return tel_fix;
    }

    public void setTel_fix(String tel_fix) {
        this.tel_fix = tel_fix;
    }

    public String getNmobile() {
        return nmobile;
    }

    public void setNmobile(String nmobile) {
        this.nmobile = nmobile;
    }

    public String getResp_hirar() {
        return resp_hirar;
    }

    public void setResp_hirar(String resp_hirar) {
        this.resp_hirar = resp_hirar;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getSos_pal() {
        return sos_pal;
    }

    public void setSos_pal(String sos_pal) {
        this.sos_pal = sos_pal;
    }

    public void setId(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
    


